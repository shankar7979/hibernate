package pack;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

public class Test {
	public static void main(String[] args) {
		Session session = new Configuration().configure().buildSessionFactory()
				.openSession();


		
//		Query qr=session.createQuery("from Employee e where e.id=? or e.ename=?")
//		//qr.setInteger(0, 1);
//		.setInteger(0, 1)
//		.setString(1, "rohan");
		
		
//		Query qr=session.createQuery("from Employee e where e.id=:empid or e.ename=:empname")
//		//qr.setInteger(0, 1);
//		.setInteger("empid", 1)
//		.setString("empname", "rohan");
		

//		Query qr=session.createQuery("from Employee e where e.id=:empid or e.ename=:empname")
//		//qr.setInteger(0, 1);
//		.setParameter("empid", 1)
//		.setParameter("empname", "rohan");

///===========================//
		
//		Employee e=new Employee();
//		e.setId(1);
//		e.setEname("mohan");
//		
//		
//		Query qr=session.createQuery("from Employee e where e.id=:id or e.ename=:ename").setProperties(e);
//		
//		//qr.setInteger(0, 1);		
//		Query qr=session.createQuery("from Employee");
//		qr.setMaxResults(10);
//		qr.setComment("rereiving max 10 record");
		
		Query qr=session.getNamedQuery("getAllEmp");
		
		
        List<Employee> list=		qr.list();
 		for (Employee employee : list) {
			System.out.println(employee.getId());
			System.out.println(employee.getEname());
		}
		
	}

}
