package pack;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import org.hibernate.Query;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;


@Stateless
public class MyTest implements MyTestRemote {

	List<Book> list;
	Session session;
@PostConstruct
 void init(){
list=new ArrayList<Book>();

	session = new Configuration().configure().buildSessionFactory()
	.openSession();	
}
	
	
	@Override
	public List<Book> getData() {
	Query qr=    session.createQuery("from Book");
	  list=     qr.list();		
		return list;
	}

//	@Resource
//	UserTransaction utx;
public	void addData(Book b1) {
session.getTransaction().begin();
session.persist(b1);
session.getTransaction().commit();
}
    

}
