package pack;
import java.util.List;

import javax.ejb.Remote;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;

@Remote
public interface MyTestRemote {
	
	List<Book> getData();
	void addData(Book b1);

}
