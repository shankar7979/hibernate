
import java.util.*;

import org.hibernate.*;
import org.hibernate.criterion.*;

public class Main {
	
	
	public static void main(String[] args) {
		HibernateUtil.setup("create table EVENTS ( uid int, name VARCHAR, start_Date date, duration int);");
		
		// hibernate code start


        SimpleEventDao eventDao = new SimpleEventDao();
        Event event = new Event();
        event.setName("Create an Event");

        
        
        try {
            eventDao.create(event);            
            eventDao.delete(event);

        } catch (ObjectNotFoundException expected) {
            // expected
        }
        


        HibernateUtil.checkData("select uid, name from events");        
		// hibernate code end
	}
	
}