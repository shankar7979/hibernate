package org.com.bean;

public class Poem {

	private int poem_id;
	private String  poem_name;
	
	public int getPoem_id() {
		return poem_id;
	}
	public void setPoem_id(int poem_id) {
		this.poem_id = poem_id;
	}
	public String getPoem_name() {
		return poem_name;
	}
	public void setPoem_name(String poem_name) {
		this.poem_name = poem_name;
	}
	
}
