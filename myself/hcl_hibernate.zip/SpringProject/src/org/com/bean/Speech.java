package org.com.bean;

public class Speech {

	private int speech_id;
	private String speech_name;
	private String speech_location;
	
	public String getSpeech_location() {
		return speech_location;
	}
	public void setSpeech_location(String speech_location) {
		this.speech_location = speech_location;
	}
	public int getSpeech_id() {
		return speech_id;
	}
	public void setSpeech_id(int speech_id) {
		this.speech_id = speech_id;
	}
	public String getSpeech_name() {
		return speech_name;
	}
	public void setSpeech_name(String speech_name) {
		this.speech_name = speech_name;
	}
	
	
}
