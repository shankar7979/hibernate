package org.com.bean;

public interface Survey {
	
String getSurveyInfo();
	
}
