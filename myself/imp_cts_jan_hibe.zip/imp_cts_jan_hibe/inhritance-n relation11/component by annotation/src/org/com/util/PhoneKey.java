package org.com.util;


import java.io.Serializable;

public class PhoneKey  implements Serializable{

	private String area;
	private int    ph_number;
	
	
}
