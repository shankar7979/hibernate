package onetooneforeignkey;

public class Person {
private int id;
private String name;

private Address addr1;

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public Address getAddr1() {
	return addr1;
}

public void setAddr1(Address addr1) {
	this.addr1 = addr1;
}



}
