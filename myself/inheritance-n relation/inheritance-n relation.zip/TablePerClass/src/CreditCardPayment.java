public class CreditCardPayment extends Payment{
  public CreditCardPayment(double amount) 
   { 
	   super(amount);
   }		  
  }
