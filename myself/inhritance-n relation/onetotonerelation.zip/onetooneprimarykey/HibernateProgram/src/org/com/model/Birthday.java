package org.com.model;

import java.util.Date;

public class Birthday {
	
	private Date date;
	private String dayname;
	
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getDayname() {
		return dayname;
	}
	public void setDayname(String dayname) {
	    
		this.dayname = dayname;
	}
	
	

}
