//package pkg1.hibernate.onetomany;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;
public class App1 
{
	private SessionFactory sessionFactory;
	Session session;

	public App1() 
	{
		try 
		{
			sessionFactory = new Configuration().configure().buildSessionFactory();
			session = sessionFactory.openSession();
		} 
		catch (Exception e) 
		{
			System.out.println("Error" + e);
		}
	}

	public static void main(String[] args) 
	{
		try {
			Long pid;
			App1 obj = new App1();
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			while (true) 
			{
				System.out.println("1. Add Parent \n" + "2. Add Child\n"
						+ "3. Add parent with child\n" + "4. Exit \n");
				int i = Integer.parseInt(br.readLine());
				switch (i) {
				case 1: {
					System.out.println("Enter parent age \n");
					int age = Integer.parseInt(br.readLine().trim());
					System.out.println("Enter parent name \n");
					String name = br.readLine().trim();
					pid = obj.createAndStoreParent(name, age);
					System.out.println("Pid..." + pid);
					break;
				}
				case 2: {
					System.out.println("Enter child age \n");
					int cage = Integer.parseInt(br.readLine().trim());
					System.out.println("Enter child name \n");
					String cname = br.readLine().trim();
					System.out.println("Enter parent id \n");
					int pid1 = Integer.parseInt(br.readLine().trim());
					obj.createAndStoreChild(cname, cage, pid1);
					System.out.println("Pid..." + pid1);
					break;
				}
				case 3: {

					obj.addParent();
					// ch1.set
					break;
				}
				case 4:
					System.exit(0);
				default:
					break;
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void addParent() throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter parent details \n " + "Enter name ");
		String pname = br.readLine();
		System.out.println("Enter parent age ");
		int page = Integer.parseInt(br.readLine());
		Parent p1 = new Parent(page, pname);
		System.out.println("How many child you want to add ");
		int nochild = Integer.parseInt(br.readLine());
		for (int i = 0; i < nochild; i++) 
		{
			System.out.println("Enter child name ");
			String cname = br.readLine();
			System.out.println("Enter child age ");
			int cage = Integer.parseInt(br.readLine());
			p1.addChild(new Child(cage, cname));
		}
		session.beginTransaction().begin();
		session.save(p1);
		Iterator itr = p1.getChildren().iterator();
		while (itr.hasNext()) 
		{
			Child ch = (Child) itr.next();
			session.save(ch);
		}
		session.beginTransaction().commit();
		System.out.println("Inserted");

	}

	private Long createAndStoreParent(String pname, int page) 
	{
		session.beginTransaction();
		Parent parent = new Parent(page, pname);
		session.save(parent);
		session.getTransaction().commit();
		return parent.getId();
	}

	private Long createAndStoreChild(String cname, int cage, int pid) 
	{
		long id = 0;
		try {
			session.beginTransaction();
			Parent p = (Parent) session.load(Parent.class, new Long(pid));
			//System.out.println("a");
			Child child = new Child();
			child.setCname(cname);
			child.setCage(cage);
			p.addChild(child);
			session.save(child);
			id = child.getId();
			// session.flush();
			session.getTransaction().commit();
		} 
		catch (ObjectNotFoundException e) 
		{
			System.out.println("Perent is not existing");
		} 
		catch (HibernateException e) {		}
		return id;
	}

}
