//package pkg1.hibernate.onetomany;
import java.util.*;

public class Parent {

    private Long id;
    private int page;
    private String pname;
    private Set children= new HashSet();

    public Parent() {}

    public Parent(int page, String pname) {
		super();
		this.page = page;
		this.pname = pname;
	}

	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

       public Set getChildren() {
        return children;
    }

    public void setChildren(Set children) {
        this.children = children;
    }

public void addChild(Child c) 
{
	c.setParent(this);
	children.add(c);
}
}